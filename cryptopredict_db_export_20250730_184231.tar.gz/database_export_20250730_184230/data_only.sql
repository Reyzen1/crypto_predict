--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: cryptocurrencies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.cryptocurrencies (id, symbol, name, coingecko_id, market_cap_rank, current_price, market_cap, total_volume, circulating_supply, total_supply, max_supply, description, website_url, blockchain_site, is_active, is_supported, created_at, updated_at, last_data_update) VALUES (1, 'BTC', 'Bitcoin', 'bitcoin', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, '2025-07-30 15:09:38.838315+03:30', '2025-07-30 15:09:38.838315+03:30', NULL);
INSERT INTO public.cryptocurrencies (id, symbol, name, coingecko_id, market_cap_rank, current_price, market_cap, total_volume, circulating_supply, total_supply, max_supply, description, website_url, blockchain_site, is_active, is_supported, created_at, updated_at, last_data_update) VALUES (2, 'ETH', 'Ethereum', 'ethereum', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, '2025-07-30 15:09:38.838315+03:30', '2025-07-30 15:09:38.838315+03:30', NULL);
INSERT INTO public.cryptocurrencies (id, symbol, name, coingecko_id, market_cap_rank, current_price, market_cap, total_volume, circulating_supply, total_supply, max_supply, description, website_url, blockchain_site, is_active, is_supported, created_at, updated_at, last_data_update) VALUES (3, 'ADA', 'Cardano', 'cardano', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, true, '2025-07-30 15:09:38.838315+03:30', '2025-07-30 15:09:38.838315+03:30', NULL);
INSERT INTO public.cryptocurrencies (id, symbol, name, coingecko_id, market_cap_rank, current_price, market_cap, total_volume, circulating_supply, total_supply, max_supply, description, website_url, blockchain_site, is_active, is_supported, created_at, updated_at, last_data_update) VALUES (4, 'DOT', 'Polkadot', 'polkadot', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, true, '2025-07-30 15:09:38.838315+03:30', '2025-07-30 15:09:38.838315+03:30', NULL);
INSERT INTO public.cryptocurrencies (id, symbol, name, coingecko_id, market_cap_rank, current_price, market_cap, total_volume, circulating_supply, total_supply, max_supply, description, website_url, blockchain_site, is_active, is_supported, created_at, updated_at, last_data_update) VALUES (5, 'SOL', 'Solana', 'solana', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, true, '2025-07-30 15:09:38.838315+03:30', '2025-07-30 15:09:38.838315+03:30', NULL);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users (id, email, password_hash, first_name, last_name, is_active, is_verified, is_superuser, created_at, updated_at, last_login, preferences) VALUES (1, 'testuser2@example.com', '$2b$12$Fl1W1olVqIwdPfncrICKXuY3y9nJpiZcapWA1lKgKleyA6foWPBbO', 'Test', 'User', true, false, false, '2025-07-30 18:27:44.884568+03:30', NULL, NULL, NULL);


--
-- Data for Name: predictions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: price_data; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: cryptocurrencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cryptocurrencies_id_seq', 5, true);


--
-- Name: predictions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.predictions_id_seq', 1, false);


--
-- Name: price_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.price_data_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- PostgreSQL database dump complete
--

