--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

-- Started on 2025-07-30 18:42:30

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.price_data DROP CONSTRAINT IF EXISTS price_data_crypto_id_fkey;
ALTER TABLE IF EXISTS ONLY public.predictions DROP CONSTRAINT IF EXISTS predictions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.predictions DROP CONSTRAINT IF EXISTS predictions_crypto_id_fkey;
DROP INDEX IF EXISTS public.ix_users_id;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_price_data_timestamp;
DROP INDEX IF EXISTS public.ix_price_data_id;
DROP INDEX IF EXISTS public.ix_price_data_crypto_id;
DROP INDEX IF EXISTS public.ix_predictions_user_id;
DROP INDEX IF EXISTS public.ix_predictions_target_datetime;
DROP INDEX IF EXISTS public.ix_predictions_model_name;
DROP INDEX IF EXISTS public.ix_predictions_id;
DROP INDEX IF EXISTS public.ix_predictions_crypto_id;
DROP INDEX IF EXISTS public.ix_predictions_created_at;
DROP INDEX IF EXISTS public.ix_cryptocurrencies_symbol;
DROP INDEX IF EXISTS public.ix_cryptocurrencies_id;
DROP INDEX IF EXISTS public.ix_cryptocurrencies_coingecko_id;
DROP INDEX IF EXISTS public.idx_price_crypto_timestamp;
DROP INDEX IF EXISTS public.idx_prediction_user_created;
DROP INDEX IF EXISTS public.idx_prediction_realized;
DROP INDEX IF EXISTS public.idx_prediction_model_performance;
DROP INDEX IF EXISTS public.idx_prediction_model_created;
DROP INDEX IF EXISTS public.idx_prediction_horizon;
DROP INDEX IF EXISTS public.idx_prediction_crypto_target;
DROP INDEX IF EXISTS public.idx_crypto_updated;
DROP INDEX IF EXISTS public.idx_crypto_symbol_active;
DROP INDEX IF EXISTS public.idx_crypto_rank;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.price_data DROP CONSTRAINT IF EXISTS price_data_pkey;
ALTER TABLE IF EXISTS ONLY public.predictions DROP CONSTRAINT IF EXISTS predictions_pkey;
ALTER TABLE IF EXISTS ONLY public.cryptocurrencies DROP CONSTRAINT IF EXISTS cryptocurrencies_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.price_data ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.predictions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cryptocurrencies ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.price_data_id_seq;
DROP TABLE IF EXISTS public.price_data;
DROP SEQUENCE IF EXISTS public.predictions_id_seq;
DROP TABLE IF EXISTS public.predictions;
DROP SEQUENCE IF EXISTS public.cryptocurrencies_id_seq;
DROP TABLE IF EXISTS public.cryptocurrencies;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 217 (class 1259 OID 16853)
-- Name: cryptocurrencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cryptocurrencies (
    id integer NOT NULL,
    symbol character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    coingecko_id character varying(50),
    market_cap_rank integer,
    current_price numeric(20,8),
    market_cap numeric(30,2),
    total_volume numeric(30,2),
    circulating_supply numeric(30,2),
    total_supply numeric(30,2),
    max_supply numeric(30,2),
    description text,
    website_url character varying(255),
    blockchain_site character varying(255),
    is_active boolean NOT NULL,
    is_supported boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_data_update timestamp with time zone
);


--
-- TOC entry 218 (class 1259 OID 16860)
-- Name: cryptocurrencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cryptocurrencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4959 (class 0 OID 0)
-- Dependencies: 218
-- Name: cryptocurrencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cryptocurrencies_id_seq OWNED BY public.cryptocurrencies.id;


--
-- TOC entry 219 (class 1259 OID 16861)
-- Name: predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.predictions (
    id integer NOT NULL,
    crypto_id integer NOT NULL,
    user_id integer,
    model_name character varying(50) NOT NULL,
    model_version character varying(20) NOT NULL,
    predicted_price numeric(20,8) NOT NULL,
    confidence_score numeric(5,4) NOT NULL,
    prediction_horizon integer NOT NULL,
    target_datetime timestamp with time zone NOT NULL,
    features_used json,
    model_parameters json,
    input_price numeric(20,8) NOT NULL,
    input_features json,
    actual_price numeric(20,8),
    accuracy_percentage numeric(5,2),
    absolute_error numeric(20,8),
    squared_error numeric(30,8),
    is_realized boolean NOT NULL,
    is_accurate boolean,
    accuracy_threshold numeric(5,2),
    training_data_end timestamp with time zone,
    market_conditions character varying(20),
    volatility_level character varying(10),
    model_training_time numeric(10,2),
    prediction_time numeric(10,6),
    notes text,
    debug_info json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    evaluated_at timestamp with time zone
);


--
-- TOC entry 220 (class 1259 OID 16868)
-- Name: predictions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.predictions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4960 (class 0 OID 0)
-- Dependencies: 220
-- Name: predictions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.predictions_id_seq OWNED BY public.predictions.id;


--
-- TOC entry 221 (class 1259 OID 16869)
-- Name: price_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_data (
    id integer NOT NULL,
    crypto_id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    open_price numeric(20,8) NOT NULL,
    high_price numeric(20,8) NOT NULL,
    low_price numeric(20,8) NOT NULL,
    close_price numeric(20,8) NOT NULL,
    volume numeric(30,8),
    market_cap numeric(30,2),
    created_at timestamp with time zone
);


--
-- TOC entry 222 (class 1259 OID 16872)
-- Name: price_data_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.price_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4961 (class 0 OID 0)
-- Dependencies: 222
-- Name: price_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.price_data_id_seq OWNED BY public.price_data.id;


--
-- TOC entry 223 (class 1259 OID 16873)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    is_active boolean,
    is_verified boolean,
    is_superuser boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    last_login timestamp with time zone,
    preferences text
);


--
-- TOC entry 224 (class 1259 OID 16879)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4962 (class 0 OID 0)
-- Dependencies: 224
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 4757 (class 2604 OID 16880)
-- Name: cryptocurrencies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cryptocurrencies ALTER COLUMN id SET DEFAULT nextval('public.cryptocurrencies_id_seq'::regclass);


--
-- TOC entry 4760 (class 2604 OID 16881)
-- Name: predictions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions ALTER COLUMN id SET DEFAULT nextval('public.predictions_id_seq'::regclass);


--
-- TOC entry 4763 (class 2604 OID 16882)
-- Name: price_data id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_data ALTER COLUMN id SET DEFAULT nextval('public.price_data_id_seq'::regclass);


--
-- TOC entry 4764 (class 2604 OID 16883)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 4946 (class 0 OID 16853)
-- Dependencies: 217
-- Data for Name: cryptocurrencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cryptocurrencies (id, symbol, name, coingecko_id, market_cap_rank, current_price, market_cap, total_volume, circulating_supply, total_supply, max_supply, description, website_url, blockchain_site, is_active, is_supported, created_at, updated_at, last_data_update) FROM stdin;
1	BTC	Bitcoin	bitcoin	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	t	2025-07-30 15:09:38.838315+03:30	2025-07-30 15:09:38.838315+03:30	\N
2	ETH	Ethereum	ethereum	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	t	2025-07-30 15:09:38.838315+03:30	2025-07-30 15:09:38.838315+03:30	\N
3	ADA	Cardano	cardano	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	t	2025-07-30 15:09:38.838315+03:30	2025-07-30 15:09:38.838315+03:30	\N
4	DOT	Polkadot	polkadot	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	t	2025-07-30 15:09:38.838315+03:30	2025-07-30 15:09:38.838315+03:30	\N
5	SOL	Solana	solana	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	t	2025-07-30 15:09:38.838315+03:30	2025-07-30 15:09:38.838315+03:30	\N
\.


--
-- TOC entry 4948 (class 0 OID 16861)
-- Dependencies: 219
-- Data for Name: predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.predictions (id, crypto_id, user_id, model_name, model_version, predicted_price, confidence_score, prediction_horizon, target_datetime, features_used, model_parameters, input_price, input_features, actual_price, accuracy_percentage, absolute_error, squared_error, is_realized, is_accurate, accuracy_threshold, training_data_end, market_conditions, volatility_level, model_training_time, prediction_time, notes, debug_info, created_at, updated_at, evaluated_at) FROM stdin;
\.


--
-- TOC entry 4950 (class 0 OID 16869)
-- Dependencies: 221
-- Data for Name: price_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_data (id, crypto_id, "timestamp", open_price, high_price, low_price, close_price, volume, market_cap, created_at) FROM stdin;
\.


--
-- TOC entry 4952 (class 0 OID 16873)
-- Dependencies: 223
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, first_name, last_name, is_active, is_verified, is_superuser, created_at, updated_at, last_login, preferences) FROM stdin;
1	testuser2@example.com	$2b$12$Fl1W1olVqIwdPfncrICKXuY3y9nJpiZcapWA1lKgKleyA6foWPBbO	Test	User	t	f	f	2025-07-30 18:27:44.884568+03:30	\N	\N	\N
\.


--
-- TOC entry 4963 (class 0 OID 0)
-- Dependencies: 218
-- Name: cryptocurrencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cryptocurrencies_id_seq', 5, true);


--
-- TOC entry 4964 (class 0 OID 0)
-- Dependencies: 220
-- Name: predictions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.predictions_id_seq', 1, false);


--
-- TOC entry 4965 (class 0 OID 0)
-- Dependencies: 222
-- Name: price_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.price_data_id_seq', 1, false);


--
-- TOC entry 4966 (class 0 OID 0)
-- Dependencies: 224
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- TOC entry 4767 (class 2606 OID 16885)
-- Name: cryptocurrencies cryptocurrencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cryptocurrencies
    ADD CONSTRAINT cryptocurrencies_pkey PRIMARY KEY (id);


--
-- TOC entry 4787 (class 2606 OID 16887)
-- Name: predictions predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT predictions_pkey PRIMARY KEY (id);


--
-- TOC entry 4793 (class 2606 OID 16889)
-- Name: price_data price_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_data
    ADD CONSTRAINT price_data_pkey PRIMARY KEY (id);


--
-- TOC entry 4797 (class 2606 OID 16891)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4768 (class 1259 OID 16892)
-- Name: idx_crypto_rank; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crypto_rank ON public.cryptocurrencies USING btree (market_cap_rank);


--
-- TOC entry 4769 (class 1259 OID 16893)
-- Name: idx_crypto_symbol_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crypto_symbol_active ON public.cryptocurrencies USING btree (symbol, is_active);


--
-- TOC entry 4770 (class 1259 OID 16894)
-- Name: idx_crypto_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crypto_updated ON public.cryptocurrencies USING btree (updated_at);


--
-- TOC entry 4774 (class 1259 OID 16895)
-- Name: idx_prediction_crypto_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_prediction_crypto_target ON public.predictions USING btree (crypto_id, target_datetime);


--
-- TOC entry 4775 (class 1259 OID 16896)
-- Name: idx_prediction_horizon; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_prediction_horizon ON public.predictions USING btree (prediction_horizon, created_at);


--
-- TOC entry 4776 (class 1259 OID 16897)
-- Name: idx_prediction_model_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_prediction_model_created ON public.predictions USING btree (model_name, created_at);


--
-- TOC entry 4777 (class 1259 OID 16898)
-- Name: idx_prediction_model_performance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_prediction_model_performance ON public.predictions USING btree (model_name, model_version, confidence_score);


--
-- TOC entry 4778 (class 1259 OID 16899)
-- Name: idx_prediction_realized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_prediction_realized ON public.predictions USING btree (is_realized, accuracy_percentage);


--
-- TOC entry 4779 (class 1259 OID 16900)
-- Name: idx_prediction_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_prediction_user_created ON public.predictions USING btree (user_id, created_at);


--
-- TOC entry 4788 (class 1259 OID 16901)
-- Name: idx_price_crypto_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_price_crypto_timestamp ON public.price_data USING btree (crypto_id, "timestamp");


--
-- TOC entry 4771 (class 1259 OID 16902)
-- Name: ix_cryptocurrencies_coingecko_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_cryptocurrencies_coingecko_id ON public.cryptocurrencies USING btree (coingecko_id);


--
-- TOC entry 4772 (class 1259 OID 16903)
-- Name: ix_cryptocurrencies_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cryptocurrencies_id ON public.cryptocurrencies USING btree (id);


--
-- TOC entry 4773 (class 1259 OID 16904)
-- Name: ix_cryptocurrencies_symbol; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_cryptocurrencies_symbol ON public.cryptocurrencies USING btree (symbol);


--
-- TOC entry 4780 (class 1259 OID 16905)
-- Name: ix_predictions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_created_at ON public.predictions USING btree (created_at);


--
-- TOC entry 4781 (class 1259 OID 16906)
-- Name: ix_predictions_crypto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_crypto_id ON public.predictions USING btree (crypto_id);


--
-- TOC entry 4782 (class 1259 OID 16907)
-- Name: ix_predictions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_id ON public.predictions USING btree (id);


--
-- TOC entry 4783 (class 1259 OID 16908)
-- Name: ix_predictions_model_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_model_name ON public.predictions USING btree (model_name);


--
-- TOC entry 4784 (class 1259 OID 16909)
-- Name: ix_predictions_target_datetime; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_target_datetime ON public.predictions USING btree (target_datetime);


--
-- TOC entry 4785 (class 1259 OID 16910)
-- Name: ix_predictions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_predictions_user_id ON public.predictions USING btree (user_id);


--
-- TOC entry 4789 (class 1259 OID 16911)
-- Name: ix_price_data_crypto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_price_data_crypto_id ON public.price_data USING btree (crypto_id);


--
-- TOC entry 4790 (class 1259 OID 16912)
-- Name: ix_price_data_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_price_data_id ON public.price_data USING btree (id);


--
-- TOC entry 4791 (class 1259 OID 16913)
-- Name: ix_price_data_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_price_data_timestamp ON public.price_data USING btree ("timestamp");


--
-- TOC entry 4794 (class 1259 OID 16914)
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- TOC entry 4795 (class 1259 OID 16915)
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- TOC entry 4798 (class 2606 OID 16916)
-- Name: predictions predictions_crypto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT predictions_crypto_id_fkey FOREIGN KEY (crypto_id) REFERENCES public.cryptocurrencies(id);


--
-- TOC entry 4799 (class 2606 OID 16921)
-- Name: predictions predictions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT predictions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4800 (class 2606 OID 16926)
-- Name: price_data price_data_crypto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_data
    ADD CONSTRAINT price_data_crypto_id_fkey FOREIGN KEY (crypto_id) REFERENCES public.cryptocurrencies(id);


-- Completed on 2025-07-30 18:42:31

--
-- PostgreSQL database dump complete
--

